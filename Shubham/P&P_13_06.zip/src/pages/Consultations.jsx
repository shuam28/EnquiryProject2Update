import React from 'react'

function Consultations() {
  return (
    <div>Consultations</div>
  )
}

export default Consultations