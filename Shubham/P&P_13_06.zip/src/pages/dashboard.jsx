import React from 'react'

function Dashboard() {
  return (
    <div>Dasboard</div>
  )
}

export default Dashboard