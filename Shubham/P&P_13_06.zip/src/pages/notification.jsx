import React from 'react'

function Notification() {
  return (
    <div>notification</div>
  )
}

export default Notification